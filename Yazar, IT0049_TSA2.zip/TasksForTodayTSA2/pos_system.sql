-- Tasks for Today Management System - TSA2 database export
-- Compatible with the migrations and demo seeder included in this project.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `pos_system`;
USE `pos_system`;

DROP TABLE IF EXISTS `tasks`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `tasks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `task_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `password`, `created_at`) VALUES
(1, 'demo', 'Demo User', 'demo@example.com', '$2y$12$E0PhUVcdkpQtNqW23UNMCOd8ITBg18T0j7pthyQyRJGQvBpCxixrG', '2026-10-07 21:00:00'),
(2, 'admin', 'Viyonce Lexi J. Yazar', 'admin@example.com', NULL, '2026-09-24 19:48:56'),
(3, 'cashier01', 'Marco Angelo B. Grageda', 'cashier01@example.com', NULL, '2026-09-24 19:48:56'),
(4, 'cashier02', 'Sudais Amerol', 'cashier02@example.com', NULL, '2026-09-24 19:48:56'),
(5, 'manager01', 'Samantha Joy F. Yerro', 'manager01@example.com', NULL, '2026-09-24 19:48:56'),
(6, 'staff01', 'Reievre Benrue B. Dacula', 'staff01@example.com', NULL, '2026-09-24 19:48:56');

INSERT INTO `tasks` (`id`, `title`, `status`, `task_date`, `created_at`, `is_archived`) VALUES
(1, 'Review project requirements', 'completed', '2026-10-07', '2026-10-07 19:00:00', 0),
(2, 'Complete CRUD implementation', 'in_progress', '2026-10-08', '2026-10-07 19:05:00', 0),
(3, 'Test authentication', 'pending', '2026-10-09', '2026-10-07 19:10:00', 0);

INSERT INTO `customers` (`id`, `full_name`, `email`, `phone`, `created_at`) VALUES
(1, 'Marco Angelo B. Grageda', 'mbgrageda@example.com', '09171234567', '2026-09-24 19:43:20'),
(2, 'Sudais Amerol', 'samerol@example.com', '09181234567', '2026-09-24 19:43:20'),
(3, 'Reievre Benrue B. Dacula', 'rbdacula@example.com', '09191234567', '2026-09-24 19:43:20'),
(4, 'Nash O. Resurreccion', 'noresurreccion@example.com', '09201234567', '2026-09-24 19:43:20'),
(5, 'Samantha Joy F. Yerro', 'sfyerro@example.com', '09211234567', '2026-09-24 19:43:20');

ALTER TABLE `users` AUTO_INCREMENT = 7;
ALTER TABLE `tasks` AUTO_INCREMENT = 4;
ALTER TABLE `customers` AUTO_INCREMENT = 6;

COMMIT;
