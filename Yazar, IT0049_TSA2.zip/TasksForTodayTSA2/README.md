# Tasks for Today Management System - TSA2

A CodeIgniter 4 implementation of the IT0049 TSA2 requirements: full CRUD for tasks, authentication, validation, and soft deletion.

## Requirements

- PHP 8.2+
- MySQL
- CodeIgniter 4 project included in this repository

## Database setup

1. Create a MySQL database named `pos_system` (or change the database settings in `.env`).
2. Update `.env` with your MySQL credentials.
3. Run:

```bash
php spark migrate
php spark db:seed DemoUserSeeder
```

The migration adds:

- `users.password` for hashed passwords
- `tasks.is_archived` for soft deletion

The demo account is:

- Username: `demo`
- Password: `password123`

The seeder stores a password hash, not the plain-text password.

## Run the application

From the project root:

```bash
php spark serve
```

Open `http://localhost:8080/`.

## Routes

### Public

- `/` - Welcome page
- `/tasks` - Task List
- `/profile` - Profile
- `/about` - About
- `/login` - Login

### Authentication required

- `/tasks/new` - New Task
- `POST /tasks` - Create Task
- `/tasks/{id}/edit` - Edit Task
- `POST /tasks/{id}` - Update Task
- `POST /tasks/{id}/delete` - Soft-delete/archive Task

`POST /logout` logs the current user out.

## Validation

The task form requires:

- `title`
- `task_date`

The status is restricted to `pending`, `in_progress`, or `completed`.

## Soft deletion

Deleting a task does not remove its database row. Instead, `is_archived` is set to `1`, and archived records are excluded from the Welcome and Task List pages.

## Security

- Passwords are verified with `password_verify()`.
- Management routes use an authentication filter.
- Forms use CodeIgniter's CSRF protection.
- User-provided output is escaped in views.
